from django.urls import path

from . import views

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('', views.RegisterPage, name="pages-register"),
    path('login/', views.LoginPage,name="pages-login"),
    path('home/', views.HomePage, name="index"),
    path('logout/', views.LogoutPage, name="logout"),
    path('search/',views.search,name="search"),
    path('profile/',views.ProfilePage,name="users-profile"),
    path('create/',views.CreatePortfolio,name="create-portfolio"),
    path('add/',views.AddPortfolio,name="add-portfolio"),
    path('stocks/', views.stock_list, name='stock_list'),
    path('predict/',views.PredictPage,name="predict_page"),

]