from django.db import models


class StockManager(models.Manager):
    def create_stock(self, name,sname, bp, quantity, dop, change, invest):
        stock = self.create(name=name,sname=sname,price=bp, quantity=quantity, date=dop, change=change, invest=invest)
        return stock


class stock(models.Model):
    name = models.CharField(max_length=20)
    sname =models.CharField(max_length=20)
    price = models.FloatField()
    quantity = models.IntegerField()
    date = models.DateField()
    change = models.FloatField()
    invest=models.FloatField()

    objects=StockManager()

