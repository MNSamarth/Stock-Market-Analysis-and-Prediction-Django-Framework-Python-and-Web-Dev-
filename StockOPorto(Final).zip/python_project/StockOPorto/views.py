from django.shortcuts import render,HttpResponse,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
import yfinance as yf
from StockOPorto.models import stock
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import datetime
import dateutil.relativedelta as rd
import io
import base64

alldata={}

def HomePage(request):
    dashboard()
    return render(request, "index.html",alldata)

def LoginPage(request):
    if request.method=='POST':
        name1=request.POST.get('name')
        pass1=request.POST.get('password')
        user=authenticate(request,username=name1,password=pass1)
        request.session['username']=name1
        request.session['password']=pass1
        global alldata
        data = {
            'username' : name1,
            'password' : pass1
        }
        print(data)
        index_prices = fetch_index_prices()

        sensex_price = index_prices['^BSESN']
        nifty_price = index_prices['^NSEI']
        banknifty = index_prices['^NSEBANK']
        alldata['sensex']=round(sensex_price,2)
        alldata['nifty']=round(nifty_price,2)
        alldata['banknifty']=round(banknifty,2)
        alldata.update(data)
        if user is not None:
            login(request,user)
            dashboard()
            return render(request, 'index.html', alldata)

    return render(request, "pages-login.html")

def RegisterPage(request):
    if request.method=='POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        password=request.POST.get('password')
        #conpass=request.POST.get('confirmpass')
        #print(password,conpass)
        #if password!=conpass:
            #return HttpResponse("Your password and confirm password are not Same")
        my_user=User.objects.create_user(name,email,password)
        my_user.save()
        return redirect('pages-login')

    return render(request,"pages-register.html")

def CreatePortfolio(request):
    if request.method=='POST':
        pass

    return render(request,'create-portfolio')

def LogoutPage(request):
    logout(request)
    return redirect('pages-login')

def search(request):
    query=request.GET.get('query')
    symbol =query
    
    try:
        stock_info = yf.Ticker(symbol)
        data = stock_info.history(period="1d")
        current_price = data ['Close'].iloc[-1]
        day_high = data ['High'].iloc[-1]
        day_low = data ['Low'].iloc[-1]
        day_open = data ['Open'].iloc[-1]
        volume = data ['Volume'].iloc[-1]
        total_value = round(1*current_price, 2)
        current_price = round(current_price,2)
        stock_data = yf.download(symbol, start="2022-01-01", end="2022-12-31")
        day_high = round(day_high,2)
        day_low = round(day_low,2)
        stock = {
            'symbol' : symbol,
            'quantity' : 1,
            'price' : current_price,
            'high' : day_high,
            'low' : day_low,
            'open' : day_open,
            'volume' : volume,
            'area' : stock_data
        }
        print(data)
        global alldata
        alldata.update(stock)
    except Exception as e:
        print(f"Error fetching stock data for {symbol}: {e}")


    return render(request, 'search.html',alldata)

def ProfilePage(request):
    return render(request,'users-profile.html',alldata)

def AddPortfolio(request):
    if request.method=='POST':
        sname=alldata['symbol']
        quantity=int(request.POST.get('qty'))
        dop=request.POST.get('date')
        bp=float(request.POST.get('buy'))
        user=alldata['username']
        curr=alldata['price']
        #conpass=request.POST.get('confirmpass')
        #print(password,conpass)
        #if password!=conpass:
            #return HttpResponse("Your password and confirm password are not Same")
        change=(curr-bp)*quantity
        alldata['change']=change
        alldata['investment']=(bp*quantity)
        invest=alldata['investment']
        my_stock=stock.objects.create_stock(user,sname,bp,quantity,dop,change,invest)
        my_stock.save()
        dashboard()
        return redirect('search')
    
    # Retrieve all persons
    all_stocks = stock.objects.all()

    # Print the retrieved data
    for stocks in all_stocks:
        print(f"Name: {stocks.name}, Price: {stocks.price}, Qty: {stocks.quantity}, Date: {stocks.date}")

    return render(request,'add-portfolio.html',alldata)

def dashboard():
    matching_records=stock.objects.filter(name=alldata['username'])
    total=0
    amount=0
    change=0
    for i in matching_records:
        curr=check(i.sname)
        part=(i.price*i.quantity)
        change=change+(curr-i.price)*i.quantity
        amount=amount+part
        total+=1
    alldata['count']=total
    alldata['investment']=round(amount,2)
    alldata['change']=round(change,2)

def check(stockname):
    price=0
    try:
        stock_info = yf.Ticker(stockname)
        data = stock_info.history(period="1d")
        price = data ['Close'].iloc[-1]
    except Exception as e:
        print(f"Error fetching stock data for {stockname}: {e}")
    return price

def stock_list(request):
    stocks = stock.objects.filter(name=alldata['username'])
    alldata['stocks']=stocks
    return render(request, 'stock_list.html', alldata)

def PredictPage(request):
    if request.method=='POST':
        sname=request.POST.get('sname')
        date=request.POST.get('date')
        price, plot_base64 = predict_and_plot_stock(sname, date)
        stock_info = yf.Ticker(sname)
        data = stock_info.history(period="1d")
        current_price = data ['Close'].iloc[-1]
        data={
            'symbol' : sname,
            'date' : date,
            'preprice' : price,
            'current' : current_price
        }
        context = {
            'predicted_price': price,
            'plot_base64': plot_base64,
        }
        alldata.update(data)
        alldata.update(context)

        return render(request,"stock_prediction.html",alldata)

    return render(request,"predict.html",alldata)

def predict_and_plot_stock(stock_symbol, prediction_date_str):
    # Convert prediction_date to a datetime object
    prediction_date = datetime.datetime.strptime(prediction_date_str, '%Y-%m-%d')

    # Calculate the start and end dates for fetching historical data
    end_date = prediction_date - datetime.timedelta(days=1)
    start_date = end_date - datetime.timedelta(days=3*365)
    
    # Fetch historical stock data using yfinance
    stock_data = yf.download(stock_symbol, start=start_date, end=end_date)
    stock_data.reset_index(inplace=True)

    # Prepare data for prediction
    X = np.arange(len(stock_data)).reshape(-1, 1)
    y = stock_data['Close'].values

    # Create and fit a linear regression model
    model = LinearRegression()
    model.fit(X, y)

    # Calculate the number of days since the start date
    days_since_start = (prediction_date - stock_data['Date'].min()).days

    # Predict stock price for the input date
    predicted_price = model.predict([[days_since_start]])[0]

    # Create the plot
    plt.figure(figsize=(10, 6))
    plt.plot(X, y, color='blue', label='Historical Data')
    plt.plot(X, model.predict(X), color='red', linestyle='--', label='Predicted Line')
    plt.axvline(x=days_since_start, color='green', linestyle=':', label='Prediction Date')
    plt.xlabel('Days')
    plt.ylabel('Stock Price')
    plt.title('Stock Price Prediction')
    plt.legend()

    # Convert the plot to bytes
    plot_bytes = io.BytesIO()
    plt.savefig(plot_bytes, format='png')
    plot_bytes.seek(0)
    
    # Encode the plot bytes as base64
    plot_base64 = base64.b64encode(plot_bytes.read()).decode('utf-8')

    return predicted_price, plot_base64


def fetch_index_prices():
    index_symbols = ['^BSESN', '^NSEI', '^NSEBANK']  # Symbols for SENSEX and NIFTY respectively

    index_data = {}
    for symbol in index_symbols:
        stock_data = yf.download(symbol)
        latest_price = stock_data['Close'][-1]
        index_data[symbol] = latest_price

    return index_data

